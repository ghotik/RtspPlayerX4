package com.sc2.sc2rtsp.x4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.versionedparcelable.VersionedParcelize;

import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceView;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.rtsp.RtspMediaSource;

public class MainActivity extends AppCompatActivity {

    //private final String TAG = BuildConfig.APPLICATION_ID;
    private final String TAG = "com.sc2.sc2Player";

    private ExoPlayer m_player1 = null;
    private ExoPlayer m_player2 = null;
    private ExoPlayer m_player3 = null;
    private ExoPlayer m_player4 = null;
    private VersionedParcelize RtspDefaultClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String uri1 = null;
        String uri2 = null;
        String uri3 = null;
        String uri4 = null;

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            uri1 = bundle.getString("uri1");
            uri2 = bundle.getString("uri2");
            uri3 = bundle.getString("uri3");
            uri4 = bundle.getString("uri4");
        }

        //uri1 =  "rtsp://31.0.225.93/cam/realmonitor?channel=3&subtype=00&authbasic=YWRtaW46MTIzOTg3";
        //uri2 =  "rtsp://31.0.225.93/cam/realmonitor?channel=3&subtype=00&authbasic=YWRtaW46MTIzOTg3";
        uri1 = "rtsp://demo:demo@ipvmdemo.dyndns.org:5541/onvif-media/media.amp?profile=profile_1_h264&sessiontimeout=60&streamtype=unicast";
        //uri1 = "https://www.youtube.com/watch?v=FlPYcgj6UdU";

        int nCams = 1;
        if(uri1 != null) nCams = 1;
        if(uri2 != null) nCams = 2;
        if(uri3 != null) nCams = 3;
        if(uri4 != null) nCams = 4;

        Point displaySize = new Point();
        this.getWindowManager().getDefaultDisplay().getRealSize(displaySize);

        Rect windowSize = new Rect();
        this.getWindow().getDecorView().getWindowVisibleDisplayFrame(windowSize);

        int width = Math.abs(windowSize.width());
        int height = (Math.abs(windowSize.height()) - 80 ) / nCams;
        if(height > width) height = width; // aspect ratio not higher than a square

        SurfaceView s1 = null;
        SurfaceView s2 = null;
        SurfaceView s3 = null;
        SurfaceView s4 = null;

        setContentView(R.layout.activity_main);

        s1 = findViewById(R.id.surfaceView1);
        if(nCams >= 1) s1.getHolder().setFixedSize(width, height);
        else s1.getHolder().setFixedSize(width, 0);

        s2 = findViewById(R.id.surfaceView2);
        if(nCams >= 2) s2.getHolder().setFixedSize(width, height);
        else s2.getHolder().setFixedSize(width, 0);

        s3 = findViewById(R.id.surfaceView3);
        if(nCams >= 3) s3.getHolder().setFixedSize(width, height);
        else s3.getHolder().setFixedSize(width, 0);

        s4 = findViewById(R.id.surfaceView4);
        if(nCams >= 4) s4.getHolder().setFixedSize(width, height);
        else s4.getHolder().setFixedSize(width, 0);

        if(uri1 != null) startPlayer(m_player1, s1, uri1, R.id.surfaceView1);
        if(uri2 != null) startPlayer(m_player2, s2, uri2, R.id.surfaceView2);
        if(uri3 != null) startPlayer(m_player3, s3, uri3, R.id.surfaceView3);
        if(uri4 != null) startPlayer(m_player4, s4, uri4, R.id.surfaceView4);
    }

    @Override
    protected void onDestroy()
    {
        Log.e(TAG, "onDestroy()");
        if(m_player1 != null) m_player1.stop();
        if(m_player2 != null) m_player2.stop();
        if(m_player3 != null) m_player3.stop();
        if(m_player4 != null) m_player4.stop();
        super.onDestroy();
    }

    void startPlayer(ExoPlayer player, SurfaceView s, String uri, int surfaceView)
    {
        try {
            player = new ExoPlayer.Builder(s.getContext()).build();
            MediaSource mediaSource =
                    new RtspMediaSource.Factory().setForceUseRtpTcp(false)
                            .setDebugLoggingEnabled(true) // remove for production ?
                            .createMediaSource(MediaItem.fromUri(uri));
            player.setMediaSource(mediaSource);
            player.prepare();
            player.setVideoSurfaceView(findViewById(surfaceView));
            player.setPlayWhenReady(true);
            //player.play();
        }
        catch(IllegalArgumentException e){
            e.printStackTrace();
            return;
        }
        catch(Exception e){
            e.printStackTrace();
            return;
        }

    }

}
